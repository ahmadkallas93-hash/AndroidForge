package com.dfb.magic.data

import java.util.UUID

/**
 * A single note (a forced list). In the public "Notes" UI this looks like
 * an ordinary note; the magician sees the underlying list of items and the
 * item that is currently set to be forced.
 */
data class NoteList(
    val id: String = UUID.randomUUID().toString(),
    var title: String,
    var items: List<String>,
    /** Index into [items] that will be forced. -1 means "not set". */
    var forcedIndex: Int = 0,
    var createdAt: Long = System.currentTimeMillis(),
    var updatedAt: Long = System.currentTimeMillis(),
    /** Optional second forced item (Pro feature). -1 means disabled. */
    var secondForcedIndex: Int = -1,
    /** The number the spectator names for the second force (Pro feature). */
    var secondNumber: Int = -1,
) {
    fun forcedItem(): String? = items.getOrNull(forcedIndex)
    fun secondForcedItem(): String? =
        if (secondForcedIndex in items.indices) items[secondForcedIndex] else null
}

/** Mechanism the magician uses to trigger the force. */
enum class ForceMechanism {
    LONG_PRESS,
    SECRET_TAP,
    VOLUME_BUTTON,
}

/** Interface / app language. */
enum class AppLanguage { SYSTEM, ENGLISH, ARABIC }

/** Light / dark / system appearance. */
enum class AppAppearance { SYSTEM, LIGHT, DARK }

/** All persisted app settings. */
data class AppSettings(
    val mechanism: ForceMechanism = ForceMechanism.LONG_PRESS,
    val language: AppLanguage = AppLanguage.SYSTEM,
    val appearance: AppAppearance = AppAppearance.SYSTEM,
    val pin: String = "2580",
    val proUnlocked: Boolean = false,
    val discreetMode: Boolean = false,
    /** Long-press duration in ms required to trigger the force. */
    val longPressDurationMs: Long = 600L,
)
