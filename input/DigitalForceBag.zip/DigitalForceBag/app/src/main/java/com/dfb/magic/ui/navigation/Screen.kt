package com.dfb.magic.ui.navigation

import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.List
import androidx.compose.material.icons.filled.Brush
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Settings
import androidx.compose.ui.graphics.vector.ImageVector

sealed class Screen(val route: String) {
    data object NotesList : Screen("notes_list")
    data object NoteView : Screen("note_view/{listId}") {
        fun createRoute(listId: String) = "note_view/$listId"
    }
    data object EditList : Screen("edit_list/{listId}") {
        fun createRoute(listId: String) = "edit_list/$listId"
    }
    data object NewList : Screen("new_list")
    data object Settings : Screen("settings")
    data object SecretConfig : Screen("secret_config")
    data object About : Screen("about")
}

data class BottomNavItem(
    val route: String,
    val labelKey: String,
    val icon: ImageVector,
)

val bottomNavItems = listOf(
    BottomNavItem("notes_list", "notes_header", Icons.AutoMirrored.Filled.List),
    BottomNavItem("secret_config", "secret_config", Icons.Filled.Lock),
    BottomNavItem("settings", "settings_title", Icons.Filled.Settings),
)
