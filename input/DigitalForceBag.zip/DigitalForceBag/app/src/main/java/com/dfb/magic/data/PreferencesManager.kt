package com.dfb.magic.data

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.intPreferencesKey
import androidx.datastore.preferences.core.longPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

private val Context.dataStore: DataStore<Preferences> by preferencesDataStore(name = "dfb_settings")

/**
 * Persists app settings and the magician's lists. Uses DataStore Preferences
 * for primitives and JSON (Gson) for the lists blob.
 */
class PreferencesManager(private val context: Context) {

    private val gson = Gson()

    // ---- Keys ----
    private val KEY_LISTS = stringPreferencesKey("lists_json")
    private val KEY_MECHANISM = stringPreferencesKey("mechanism")
    private val KEY_LANGUAGE = stringPreferencesKey("language")
    private val KEY_APPEARANCE = stringPreferencesKey("appearance")
    private val KEY_PIN = stringPreferencesKey("pin")
    private val KEY_PRO = booleanPreferencesKey("pro_unlocked")
    private val KEY_DISCREET = booleanPreferencesKey("discreet_mode")
    private val KEY_LONG_PRESS_MS = longPreferencesKey("long_press_ms")
    private val KEY_INITIALIZED = booleanPreferencesKey("initialized")

    // ---- Lists ----
    val listsFlow: Flow<List<NoteList>> = context.dataStore.data.map { prefs ->
        val json = prefs[KEY_LISTS]
        if (json.isNullOrBlank()) {
            SampleData.defaultLists()
        } else {
            try {
                val type = object : TypeToken<List<NoteList>>() {}.type
                gson.fromJson(json, type) ?: SampleData.defaultLists()
        }
        }
    }

    suspend fun saveLists(lists: List<NoteList>) {
        context.dataStore.edit { prefs ->
            prefs[KEY_LISTS] = gson.toJson(lists)
        }
    }

    // ---- Settings ----
    val settingsFlow: Flow<AppSettings> = context.dataStore.data.map { prefs ->
        AppSettings(
            mechanism = ForceMechanism.valueOf(
                prefs[KEY_MECHANISM] ?: ForceMechanism.LONG_PRESS.name
            ),
            language = AppLanguage.valueOf(
                prefs[KEY_LANGUAGE] ?: AppLanguage.SYSTEM.name
            ),
            appearance = AppAppearance.valueOf(
                prefs[KEY_APPEARANCE] ?: AppAppearance.SYSTEM.name
            ),
            pin = prefs[KEY_PIN] ?: "2580",
            proUnlocked = prefs[KEY_PRO] ?: false,
            discreetMode = prefs[KEY_DISCREET] ?: false,
            longPressDurationMs = prefs[KEY_LONG_PRESS_MS] ?: 600L,
        )
    }

    suspend fun setMechanism(m: ForceMechanism) {
        context.dataStore.edit { it[KEY_MECHANISM] = m.name }
    }

    suspend fun setLanguage(l: AppLanguage) {
        context.dataStore.edit { it[KEY_LANGUAGE] = l.name }
    }

    suspend fun setAppearance(a: AppAppearance) {
        context.dataStore.edit { it[KEY_APPEARANCE] = a.name }
    }

    suspend fun setPin(pin: String) {
        context.dataStore.edit { it[KEY_PIN] = pin }
    }

    suspend fun setProUnlocked(value: Boolean) {
        context.dataStore.edit { it[KEY_PRO] = value }
    }

    suspend fun setDiscreetMode(value: Boolean) {
        context.dataStore.edit { it[KEY_DISCREET] = value }
    }

    suspend fun setLongPressDuration(ms: Long) {
        context.dataStore.edit { it[KEY_LONG_PRESS_MS] = ms }
    }

    suspend fun ensureInitialized() {
        context.dataStore.edit { prefs ->
            if (!prefs[KEY_INITIALIZED]) {
                prefs[KEY_LISTS] = gson.toJson(SampleData.defaultLists())
                prefs[KEY_INITIALIZED] = true
            }
        }
    }
}
