package com.dfb.magic.ui.theme

import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.ui.graphics.Color

// iOS Notes — light
val DFBColorsLight = lightColorScheme(
    primary = Color(0xFFFFB340),
    onPrimary = Color.Black,
    primaryContainer = Color(0xFFFFE468),
    onPrimaryContainer = Color.Black,
    secondary = Color(0xFFFFB340),
    onSecondary = Color.Black,
    background = Color(0xFFF7F7F7),
    onBackground = Color(0xFF000000),
    surface = Color(0xFFFFFFFF),
    onSurface = Color(0xFF000000),
    surfaceVariant = Color(0xFFEFEFF2),
    onSurfaceVariant = Color(0xFF3C3C43),
    outline = Color(0xFFE5E5EA),
    error = Color(0xFFFF3B30),
    onError = Color.White,
)

// iOS Notes — dark
val DFBColorsDark = darkColorScheme(
    primary = Color(0xFFFFB340),
    onPrimary = Color.Black,
    primaryContainer = Color(0xFFF5C518),
    onPrimaryContainer = Color.Black,
    secondary = Color(0xFFFFB340),
    onSecondary = Color.Black,
    background = Color(0xFF000000),
    onBackground = Color(0xFFFFFFFF),
    surface = Color(0xFF1C1C1E),
    onSurface = Color(0xFFFFFFFF),
    surfaceVariant = Color(0xFF2C2C2E),
    onSurfaceVariant = Color(0xFFD6D6D9),
    outline = Color(0xFF38383A),
    error = Color(0xFFFF453A),
    onError = Color.Black,
)

object DFBColors {
    val iosYellow = Color(0xFFFFE468)
    val iosYellowDark = Color(0xFFF5C518)
    val iosAccent = Color(0xFFFFB340)
    val iosBlue = Color(0xFF007AFF)
    val iosRed = Color(0xFFFF3B30)
    val iosGreen = Color(0xFF34C759)
    val iosSearchBgLight = Color(0xFFE0E0E5)
    val iosSearchBgDark = Color(0xFF3A3A3C)
    val iosSeparatorLight = Color(0xFFE5E5EA)
    val iosSeparatorDark = Color(0xFF38383A)
    val iosSecondaryLight = Color(0xFF8E8E93)
    val iosSecondaryDark = Color(0xFF98989F)
}
