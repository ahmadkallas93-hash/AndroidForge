package com.dfb.magic.ui.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.dfb.magic.data.AppAppearance
import com.dfb.magic.data.AppLanguage
import com.dfb.magic.data.AppSettings
import com.dfb.magic.data.DFBRepository
import com.dfb.magic.data.ForceMechanism
import com.dfb.magic.data.NoteList
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

data class ForceResultState(
    val item: String = "",
    val secondItem: String? = null,
    val listTitle: String = "",
)

class DFBViewModel(private val repo: DFBRepository) : ViewModel() {

    val lists: StateFlow<List<NoteList>> = repo.listsFlow.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = emptyList(),
    )

    val settings: StateFlow<AppSettings> = repo.settingsFlow.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = AppSettings(),
    )

    private val _forceResult = MutableStateFlow(ForceResultState())
    val forceResult: StateFlow<ForceResultState> = _forceResult.asStateFlow()

    fun ensureInitialized() {
        viewModelScope.launch { repo.ensureInitialized() }
    }

    // ---- List operations ----
    fun addList(title: String, items: List<String>, forcedIndex: Int = 0, onDone: (String) -> Unit = {}) {
        viewModelScope.launch {
            val id = repo.addList(title, items, forcedIndex)
            onDone(id)
        }
    }

    fun updateList(updated: NoteList, onDone: () -> Unit = {}) {
        viewModelScope.launch {
            repo.updateList(updated)
            onDone()
        }
    }

    fun deleteList(id: String, onDone: (Boolean) -> Unit = {}) {
        viewModelScope.launch { onDone(repo.deleteList(id)) }
    }

    fun setForcedItem(listId: String, itemIndex: Int) {
        viewModelScope.launch { repo.setForcedItem(listId, itemIndex) }
    }

    // ---- Force trigger ----
    fun performForce(list: NoteList, useSecond: Boolean = false) {
        val item = if (useSecond) list.secondForcedItem() else list.forcedItem()
        _forceResult.value = ForceResultState(
            item = item ?: "",
            secondItem = if (useSecond) null else list.secondForcedItem(),
            listTitle = list.title,
        )
    }

    fun clearForce() {
        _forceResult.value = ForceResultState()
    }

    // ---- Settings ----
    fun setMechanism(m: ForceMechanism) { viewModelScope.launch { repo.setMechanism(m) } }
    fun setLanguage(l: AppLanguage) { viewModelScope.launch { repo.setLanguage(l) } }
    fun setAppearance(a: AppAppearance) { viewModelScope.launch { repo.setAppearance(a) } }
    fun setPin(pin: String) { viewModelScope.launch { repo.setPin(pin) } }
    fun setProUnlocked(v: Boolean) { viewModelScope.launch { repo.setProUnlocked(v) } }
    fun setDiscreetMode(v: Boolean) { viewModelScope.launch { repo.setDiscreetMode(v) } }
    fun setLongPressDuration(ms: Long) { viewModelScope.launch { repo.setLongPressDuration(ms) } }

    companion object {
        fun factory(repo: DFBRepository) = object : ViewModelProvider.Factory {
            @Suppress("UNCHECKED_CAST")
            override fun <T : ViewModel> create(modelClass: Class<T>): T = DFBViewModel(repo) as T
        }
    }
}
