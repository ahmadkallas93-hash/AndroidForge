package com.dfb.magic.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Star
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.dfb.magic.data.NoteList
import com.dfb.magic.ui.theme.DFBColors
import com.dfb.magic.ui.viewmodel.DFBViewModel

@Composable
fun EditListDialog(
    initial: NoteList,
    onSave: (NoteList) -> Unit,
    onDismiss: () -> Unit,
) {
    val context = LocalContext.current
    var title by remember { mutableStateOf(initial.title) }
    var items by remember { mutableStateOf(initial.items.toMutableList()) }
    var forcedIndex by remember { mutableStateOf(initial.forcedIndex) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(context.getString(com.dfb.magic.R.string.edit_list), fontWeight = FontWeight.Bold) },
        text = {
            Column(modifier = Modifier.fillMaxWidth()) {
                OutlinedTextField(
                    value = title,
                    onValueChange = { title = it },
                    label = { Text(context.getString(com.dfb.magic.R.string.list_title)) },
                    singleLine = true,
                    isError = title.isBlank(),
                    modifier = Modifier.fillMaxWidth(),
                )
                Spacer(Modifier.height(12.dp))
                Text(
                    text = context.getString(com.dfb.magic.R.string.items),
                    style = MaterialTheme.typography.labelMedium,
                    color = DFBColors.iosSecondaryLight,
                    modifier = Modifier.padding(vertical = 4.dp),
                )
                LazyColumn(
                    modifier = Modifier
                        .fillMaxWidth()
                        .heightIn(max = 320.dp),
                    verticalArrangement = Arrangement.spacedBy(6.dp),
                ) {
                    items(items.size) { index ->
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically,
                        ) {
                            IconButton(
                                onClick = { forcedIndex = index },
                                modifier = Modifier.size(36.dp),
                            ) {
                                Icon(
                                    imageVector = Icons.Filled.Star,
                                    contentDescription = context.getString(
                                        com.dfb.magic.R.string.set_forced
                                    ),
                                    tint = if (index == forcedIndex) DFBColors.iosAccent
                                        else DFBColors.iosSecondaryLight,
                                )
                            }
                            OutlinedTextField(
                                value = items[index],
                                onValueChange = { value ->
                                    items = items.toMutableList().also {
                                        it[index] = value
                                        if (index == it.lastIndex && value.isNotBlank()) {
                                            it.add("")
                                        }
                                    }
                                },
                                placeholder = {
                                    Text(context.getString(com.dfb.magic.R.string.item_placeholder))
                                },
                                singleLine = true,
                                modifier = Modifier.weight(1f),
                            )
                            if (items.size > 2) {
                                IconButton(
                                    onClick = {
                                        val newItems = items.toMutableList()
                                        newItems.removeAt(index)
                                        items = newItems
                                        if (forcedIndex >= items.size) forcedIndex = items.lastIndex
                                    },
                                    modifier = Modifier.size(36.dp),
                                ) {
                                    Icon(
                                        imageVector = Icons.Filled.Delete,
                                        contentDescription = context.getString(
                                            com.dfb.magic.R.string.delete
                                        ),
                                        tint = DFBColors.iosSecondaryLight,
                                    )
                                }
                            }
                        }
                    }
                }
                Spacer(Modifier.height(8.dp))
                Text(
                    text = "★ = " + context.getString(com.dfb.magic.R.string.forced_item) +
                        ": " + items.getOrNull(forcedIndex),
                    style = MaterialTheme.typography.labelSmall,
                    color = DFBColors.iosAccent,
                )
            }
        },
        confirmButton = {
            TextButton(onClick = {
                val cleaned = items.map { it.trim() }.filter { it.isNotBlank() }
                if (title.isBlank() || cleaned.size < 2) return@TextButton
                val idx = forcedIndex.coerceIn(0, cleaned.lastIndex)
                onSave(initial.copy(title = title.trim(), items = cleaned, forcedIndex = idx))
            }) {
                Text(context.getString(com.dfb.magic.R.string.save), color = DFBColors.iosAccent)
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text(context.getString(com.dfb.magic.R.string.cancel), color = DFBColors.iosAccent)
            }
        },
    )
}
