package com.dfb.magic.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Brush
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Public
import androidx.compose.material.icons.filled.TouchApp
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import com.dfb.magic.data.AppAppearance
import com.dfb.magic.data.AppLanguage
import com.dfb.magic.data.ForceMechanism
import com.dfb.magic.ui.theme.DFBColors
import com.dfb.magic.ui.viewmodel.DFBViewModel

@Composable
fun SettingsScreen(
    viewModel: DFBViewModel,
    onBack: () -> Unit,
    onAbout: () -> Unit,
) {
    val settings by viewModel.settings.collectAsState()
    val context = LocalContext.current
    var showLanguageDialog by remember { mutableStateOf(false) }
    var showAppearanceDialog by remember { mutableStateOf(false) }
    var showPinDialog by remember { mutableStateOf(false) }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(context.getString(com.dfb.magic.R.string.settings_title)) },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(
                            imageVector = androidx.compose.material.icons.Icons.AutoMirrored.Filled.ArrowBack,
                            contentDescription = "Back",
                            tint = DFBColors.iosAccent,
                        )
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.background,
                ),
            )
        },
        containerColor = MaterialTheme.colorScheme.background,
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding),
        ) {
            IOSGroupedSection(title = context.getString(com.dfb.magic.R.string.force_mechanism)) {
                ForceMechanism.values().forEachIndexed { idx, m ->
                    IOSListRow(
                        title = context.getString(when (m) {
                            ForceMechanism.LONG_PRESS -> com.dfb.magic.R.string.long_press
                            ForceMechanism.SECRET_TAP -> com.dfb.magic.R.string.secret_tap
                            ForceMechanism.VOLUME_BUTTON -> com.dfb.magic.R.string.volume_button
                        }),
                        subtitle = context.getString(when (m) {
                            ForceMechanism.LONG_PRESS -> com.dfb.magic.R.string.long_press_desc
                            ForceMechanism.SECRET_TAP -> com.dfb.magic.R.string.secret_tap_desc
                            ForceMechanism.VOLUME_BUTTON -> com.dfb.magic.R.string.volume_button_desc
                        }),
                        showChevron = false,
                        trailing = {
                            RadioButton(
                                selected = settings.mechanism == m,
                                onClick = { viewModel.setMechanism(m) },
                            )
                        },
                        onClick = { viewModel.setMechanism(m) },
                    )
                    if (idx < ForceMechanism.values().size - 1) IOSSeparator()
                }
            }

            IOSGroupedSection(title = context.getString(com.dfb.magic.R.string.appearance)) {
                IOSListRow(
                    icon = { Icon(Icons.Filled.Brush, null, tint = Color.White) },
                    iconBg = DFBColors.iosAccent,
                    title = context.getString(com.dfb.magic.R.string.appearance),
                    value = when (settings.appearance) {
                        AppAppearance.SYSTEM -> context.getString(com.dfb.magic.R.string.system_default)
                        AppAppearance.LIGHT -> context.getString(com.dfb.magic.R.string.light)
                        AppAppearance.DARK -> context.getString(com.dfb.magic.R.string.dark)
                    },
                    onClick = { showAppearanceDialog = true },
                )
                IOSSeparator()
                IOSListRow(
                    icon = { Icon(Icons.Filled.Public, null, tint = Color.White) },
                    iconBg = DFBColors.iosBlue,
                    title = context.getString(com.dfb.magic.R.string.language),
                    value = when (settings.language) {
                        AppLanguage.SYSTEM -> context.getString(com.dfb.magic.R.string.system_default)
                        AppLanguage.ENGLISH -> context.getString(com.dfb.magic.R.string.english)
                        AppLanguage.ARABIC -> context.getString(com.dfb.magic.R.string.arabic)
                    },
                    onClick = { showLanguageDialog = true },
                )
            }

            IOSGroupedSection(title = context.getString(com.dfb.magic.R.string.pro_features)) {
                IOSListRow(
                    icon = { Icon(Icons.Filled.Lock, null, tint = Color.White) },
                    iconBg = DFBColors.iosBlue,
                    title = context.getString(com.dfb.magic.R.string.pro_features),
                    subtitle = context.getString(com.dfb.magic.R.string.pro_features_desc),
                    showChevron = false,
                    trailing = {
                        Switch(
                            checked = settings.proUnlocked,
                            onCheckedChange = { viewModel.setProUnlocked(it) },
                        )
                    },
                )
                IOSSeparator()
                IOSListRow(
                    icon = { Icon(Icons.Filled.TouchApp, null, tint = Color.White) },
                    iconBg = DFBColors.iosBlue,
                    title = context.getString(com.dfb.magic.R.string.discreet_mode),
                    subtitle = context.getString(com.dfb.magic.R.string.discreet_mode_desc),
                    showChevron = false,
                    trailing = {
                        Switch(
                            checked = settings.discreetMode,
                            onCheckedChange = { viewModel.setDiscreetMode(it) },
                        )
                    },
                )
            }

            IOSGroupedSection {
                IOSListRow(
                    icon = { Icon(Icons.Filled.Info, null, tint = Color.White) },
                    iconBg = DFBColors.iosBlue,
                    title = context.getString(com.dfb.magic.R.string.about),
                    onClick = onAbout,
                )
            }
        }
    }

    if (showLanguageDialog) {
        AlertDialog(
            onDismissRequest = { showLanguageDialog = false },
            confirmButton = {},
            text = {
                Column {
                    AppLanguage.values().forEach { l ->
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 8.dp),
                            verticalAlignment = androidx.compose.ui.Alignment.CenterVertically,
                        ) {
                            RadioButton(
                                selected = settings.language == l,
                                onClick = {
                                    viewModel.setLanguage(l)
                                    showLanguageDialog = false
                                },
                            )
                            Text(
                                text = when (l) {
                                    AppLanguage.SYSTEM -> context.getString(com.dfb.magic.R.string.system_default)
                                    AppLanguage.ENGLISH -> context.getString(com.dfb.magic.R.string.english)
                                    AppLanguage.ARABIC -> context.getString(com.dfb.magic.R.string.arabic)
                                },
                                modifier = Modifier.padding(start = 8.dp),
                            )
                        }
                    }
                }
            },
        )
    }

    if (showAppearanceDialog) {
        AlertDialog(
            onDismissRequest = { showAppearanceDialog = false },
            confirmButton = {},
            text = {
                Column {
                    AppAppearance.values().forEach { a ->
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 8.dp),
                            verticalAlignment = androidx.compose.ui.Alignment.CenterVertically,
                        ) {
                            RadioButton(
                                selected = settings.appearance == a,
                                onClick = {
                                    viewModel.setAppearance(a)
                                    showAppearanceDialog = false
                                },
                            )
                            Text(
                                text = when (a) {
                                    AppAppearance.SYSTEM -> context.getString(com.dfb.magic.R.string.system_default)
                                    AppAppearance.LIGHT -> context.getString(com.dfb.magic.R.string.light)
                                    AppAppearance.DARK -> context.getString(com.dfb.magic.R.string.dark)
                                },
                                modifier = Modifier.padding(start = 8.dp),
                            )
                        }
                    }
                }
            },
        )
    }
}
