package com.dfb.magic.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.Composable

/**
 * Public entry-point for the app theme. Forwards to the color + typography
 * defined in [Color.kt] and [Type.kt].
 */
@Composable
fun DFBTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    content: @Composable () -> Unit,
) {
    MaterialTheme(
        colorScheme = if (darkTheme) DFBColorsDark else DFBColorsLight,
        typography = DFBTypography,
        content = content,
    )
}
