package com.dfb.magic.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.dfb.magic.data.AppAppearance
import com.dfb.magic.data.AppLanguage
import com.dfb.magic.data.ForceMechanism
import com.dfb.magic.data.NoteList
import com.dfb.magic.ui.theme.DFBColors
import com.dfb.magic.ui.viewmodel.DFBViewModel

@Composable
fun SecretConfigScreen(
    viewModel: DFBViewModel,
    onAuthenticated: () -> Unit,
    initialListId: String? = null,
) {
    val settings by viewModel.settings.collectAsState()
    val context = LocalContext.current
    var pin by remember { mutableStateOf("") }
    var error by remember { mutableStateOf(false) }
    var authenticated by remember { mutableStateOf(false) }

    if (!authenticated) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .background(MaterialTheme.colorScheme.background)
                .padding(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center,
        ) {
            Box(
                modifier = Modifier
                    .size(72.dp)
                    .clip(CircleShape)
                    .background(DFBColors.iosAccent),
                contentAlignment = Alignment.Center,
            ) {
                Icon(
                    imageVector = Icons.Filled.Lock,
                    contentDescription = null,
                    tint = androidx.compose.ui.graphics.Color.Black,
                    modifier = Modifier.size(36.dp),
                )
            }
            Spacer(Modifier.height(20.dp))
            Text(
                text = context.getString(com.dfb.magic.R.string.enter_pin),
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.SemiBold,
                textAlign = TextAlign.Center,
            )
            Spacer(Modifier.height(8.dp))
            Text(
                text = context.getString(com.dfb.magic.R.string.pin_hint),
                style = MaterialTheme.typography.bodySmall,
                color = DFBColors.iosSecondaryLight,
                textAlign = TextAlign.Center,
            )
            Spacer(Modifier.height(24.dp))
            OutlinedTextField(
                value = pin,
                onValueChange = { pin = it.filter { c -> c.isDigit() }.take(6) },
                label = { Text("PIN") },
                singleLine = true,
                visualTransformation = PasswordVisualTransformation(),
                isError = error,
                modifier = Modifier.fillMaxWidth(),
            )
            if (error) {
                Text(
                    text = context.getString(com.dfb.magic.R.string.wrong_pin),
                    color = MaterialTheme.colorScheme.error,
                    style = MaterialTheme.typography.bodySmall,
                    modifier = Modifier.padding(top = 8.dp),
                )
            }
            Spacer(Modifier.height(20.dp))
            Button(
                onClick = {
                    if (pin == settings.pin) {
                        error = false
                        authenticated = true
                        onAuthenticated()
                    } else {
                        error = true
                    }
                },
                modifier = Modifier.fillMaxWidth(),
                colors = ButtonDefaults.buttonColors(
                    containerColor = DFBColors.iosAccent,
                    contentColor = androidx.compose.ui.graphics.Color.Black,
                ),
            ) {
                Text(context.getString(com.dfb.magic.R.string.enter))
            }
        }
        return
    }

    // Once authenticated — show the magician's controls
    SecretControlsContent(viewModel = viewModel, initialListId = initialListId)
}

@Composable
private fun SecretControlsContent(viewModel: DFBViewModel, initialListId: String? = null) {
    val lists by viewModel.lists.collectAsState()
    val settings by viewModel.settings.collectAsState()
    val context = LocalContext.current
    var editingListId by remember { mutableStateOf(initialListId) }
    var showNewList by remember { mutableStateOf(false) }

    if (showNewList) {
        EditListDialog(
            initial = NoteList(title = "", items = listOf("", ""), forcedIndex = 0),
            onSave = { saved ->
                viewModel.addList(saved.title, saved.items, saved.forcedIndex) { showNewList = false }
            },
            onDismiss = { showNewList = false },
        )
        return
    }
    editingListId?.let { id ->
        val current = lists.firstOrNull { it.id == id }
        if (current != null) {
            EditListDialog(
                initial = current,
                onSave = { saved -> viewModel.updateList(saved) { editingListId = null } },
                onDismiss = { editingListId = null },
            )
            return
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(context.getString(com.dfb.magic.R.string.secret_config)) },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.background,
                ),
                actions = {
                    TextButton(onClick = { showNewList = true }) {
                        Text(
                            context.getString(com.dfb.magic.R.string.new_list),
                            color = DFBColors.iosAccent,
                        )
                    }
                },
            )
        },
        containerColor = MaterialTheme.colorScheme.background,
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(top = 8.dp),
        ) {
            IOSGroupedSection(title = context.getString(com.dfb.magic.R.string.force_mechanism)) {
                ForceMechanism.values().forEachIndexed { idx, m ->
                    IOSListRow(
                        title = context.getString(when (m) {
                            ForceMechanism.LONG_PRESS -> com.dfb.magic.R.string.long_press
                            ForceMechanism.SECRET_TAP -> com.dfb.magic.R.string.secret_tap
                            ForceMechanism.VOLUME_BUTTON -> com.dfb.magic.R.string.volume_button
                        }),
                        subtitle = context.getString(when (m) {
                            ForceMechanism.LONG_PRESS -> com.dfb.magic.R.string.long_press_desc
                            ForceMechanism.SECRET_TAP -> com.dfb.magic.R.string.secret_tap_desc
                            ForceMechanism.VOLUME_BUTTON -> com.dfb.magic.R.string.volume_button_desc
                        }),
                        showChevron = false,
                        trailing = {
                            RadioButton(
                                selected = settings.mechanism == m,
                                onClick = { viewModel.setMechanism(m) },
                            )
                        },
                        onClick = { viewModel.setMechanism(m) },
                    )
                    if (idx < ForceMechanism.values().size - 1) IOSSeparator()
                }
            }

            IOSGroupedSection(title = context.getString(com.dfb.magic.R.string.notes_header)) {
                lists.forEachIndexed { idx, list ->
                    IOSListRow(
                        title = list.title,
                        subtitle = context.getString(
                            com.dfb.magic.R.string.items_count, list.items.size
                        ),
                        value = list.forcedItem() ?: "—",
                        onClick = { editingListId = list.id },
                    )
                    if (idx < lists.size - 1) IOSSeparator()
                }
            }

            IOSGroupedSection(
                title = context.getString(com.dfb.magic.R.string.pro_features),
                footer = if (!settings.proUnlocked)
                    context.getString(com.dfb.magic.R.string.pro_features_desc) else null,
            ) {
                IOSListRow(
                    title = context.getString(com.dfb.magic.R.string.pro_features),
                    subtitle = context.getString(com.dfb.magic.R.string.pro_features_desc),
                    showChevron = false,
                    trailing = {
                        Switch(
                            checked = settings.proUnlocked,
                            onCheckedChange = { viewModel.setProUnlocked(it) },
                        )
                    },
                )
                IOSSeparator()
                IOSListRow(
                    title = context.getString(com.dfb.magic.R.string.discreet_mode),
                    subtitle = context.getString(com.dfb.magic.R.string.discreet_mode_desc),
                    showChevron = false,
                    trailing = {
                        Switch(
                            checked = settings.discreetMode,
                            onCheckedChange = { viewModel.setDiscreetMode(it) },
                        )
                    },
                )
            }
        }
    }
}
