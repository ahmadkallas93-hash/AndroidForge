package com.dfb.magic.ui.navigation

import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import com.dfb.magic.data.DFBRepository
import com.dfb.magic.data.PreferencesManager
import com.dfb.magic.ui.screens.AboutScreen
import com.dfb.magic.ui.screens.NotesListScreen
import com.dfb.magic.ui.screens.NoteViewScreen
import com.dfb.magic.ui.screens.ResultScreen
import com.dfb.magic.ui.screens.SecretConfigScreen
import com.dfb.magic.ui.screens.SettingsScreen
import com.dfb.magic.ui.viewmodel.DFBViewModel

@Composable
fun DFBNavHost() {
    val navController = rememberNavController()
    val context = androidx.compose.ui.platform.LocalContext.current
    val viewModel: DFBViewModel = viewModel(factory = DFBViewModel.factory(
        DFBRepository(PreferencesManager(context.applicationContext as android.app.Application))
    ))

    LaunchedEffect(Unit) { viewModel.ensureInitialized() }

    NavHost(navController = navController, startDestination = Screen.NotesList.route) {
        composable(Screen.NotesList.route) {
            NotesListScreen(
                viewModel = viewModel,
                onNoteClick = { note -> navController.navigate(Screen.NoteView.createRoute(note.id)) },
                onNewNote = { navController.navigate(Screen.NewList.route) },
                onOpenSettings = { navController.navigate(Screen.Settings.route) },
                onOpenSecret = { navController.navigate(Screen.SecretConfig.route) },
            )
        }
        composable(
            route = Screen.NoteView.route,
            arguments = listOf(navArgument("listId") { type = NavType.StringType }),
        ) { entry ->
            val listId = entry.arguments?.getString("listId") ?: ""
            NoteViewScreen(
                viewModel = viewModel,
                listId = listId,
                onBack = { navController.popBackStack() },
                onEdit = { id -> navController.navigate(Screen.EditList.createRoute(id)) },
                onForceReveal = { navController.navigate(Screen.Result.route) },
            )
        }
        composable(Screen.NewList.route) {
            SecretConfigScreen(
                viewModel = viewModel,
                onAuthenticated = { navController.popBackStack() },
            )
        }
        composable(
            route = Screen.EditList.route,
            arguments = listOf(navArgument("listId") { type = NavType.StringType }),
        ) { entry ->
            val listId = entry.arguments?.getString("listId") ?: ""
            SecretConfigScreen(
                viewModel = viewModel,
                onAuthenticated = {
                    navController.navigate(Screen.NotesList.route) {
                        popUpTo(Screen.NotesList.route) { inclusive = false }
                    }
                },
                initialListId = listId,
            )
        }
        composable(Screen.Settings.route) {
            SettingsScreen(
                viewModel = viewModel,
                onBack = { navController.popBackStack() },
                onAbout = { navController.navigate(Screen.About.route) },
            )
        }
        composable(Screen.SecretConfig.route) {
            SecretConfigScreen(
                viewModel = viewModel,
                onAuthenticated = { /* stays on this screen */ },
            )
        }
        composable(Screen.Result.route) {
            ResultScreen(
                viewModel = viewModel,
                onPickAnother = { navController.popBackStack() },
                onClose = {
                    navController.popBackStack(Screen.NotesList.route, inclusive = false)
                },
            )
        }
        composable(Screen.About.route) {
            AboutScreen(onBack = { navController.popBackStack() })
        }
    }
}
