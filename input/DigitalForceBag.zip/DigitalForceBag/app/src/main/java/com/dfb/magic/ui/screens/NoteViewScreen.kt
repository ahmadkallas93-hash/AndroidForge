package com.dfb.magic.ui.screens

import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.MoreHoriz
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.dfb.magic.data.ForceMechanism
import com.dfb.magic.data.NoteList
import com.dfb.magic.ui.theme.DFBColors
import com.dfb.magic.ui.viewmodel.DFBViewModel
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun NoteViewScreen(
    viewModel: DFBViewModel,
    listId: String,
    onBack: () -> Unit,
    onEdit: (String) -> Unit,
    onForceReveal: () -> Unit,
) {
    val lists by viewModel.lists.collectAsState()
    val settings by viewModel.settings.collectAsState()
    val context = LocalContext.current
    val list = lists.firstOrNull { it.id == listId }

    var secretTapCount by remember { mutableStateOf(0) }
    var lastTapTime by remember { mutableStateOf(0L) }
    var showMenu by remember { mutableStateOf(false) }
    var forceTriggered by remember { mutableStateOf(false) }

    val dateFmt = remember { SimpleDateFormat("EEEE, MMM d, yyyy", Locale.getDefault()) }

    if (list == null) {
        Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            Text("Note not found")
        }
        return
    }

    // Volume-button mechanism is handled at the Activity level via a hardware
    // key listener when ForceMechanism.VOLUME_BUTTON is selected. Here we
    // expose the two touch-based mechanisms (long press + secret tap).

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Text(
                        text = dateFmt.format(Date(list.updatedAt)),
                        style = MaterialTheme.typography.bodyMedium,
                        fontWeight = FontWeight.Normal,
                    )
                },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(
                            imageVector = androidx.compose.material.icons.Icons.AutoMirrored.Filled.ArrowBack,
                            contentDescription = "Back",
                            tint = DFBColors.iosAccent,
                        )
                    }
                },
                actions = {
                    IconButton(onClick = { showMenu = true }) {
                        Icon(
                            imageVector = Icons.Filled.MoreHoriz,
                            contentDescription = "More",
                            tint = DFBColors.iosAccent,
                        )
                    }
                    DropdownMenu(expanded = showMenu, onDismissRequest = { showMenu = false }) {
                        DropdownMenuItem(
                            text = { Text("Edit list") },
                            onClick = {
                                showMenu = false
                                onEdit(list.id)
                            },
                        )
                        DropdownMenuItem(
                            text = { Text("Settings") },
                            onClick = {
                                showMenu = false
                                // open settings via secret path handled in nav
                            },
                        )
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.background,
                ),
            )
        },
        containerColor = MaterialTheme.colorScheme.background,
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 20.dp, vertical = 16.dp),
        ) {
            Text(
                text = list.title,
                style = MaterialTheme.typography.headlineMedium,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.onBackground,
                modifier = Modifier
                    .fillMaxWidth()
                    .pointerInput(list.id, settings.mechanism) {
                        detectTapGestures(
                            onLongPress = {
                                if (settings.mechanism == ForceMechanism.LONG_PRESS) {
                                    triggerForce(viewModel, list) {
                                        forceTriggered = true
                                        onForceReveal()
                                    }
                                }
                            },
                            onTap = {
                                // Secret-tap mechanism: 3 quick taps on the note title
                                if (settings.mechanism == ForceMechanism.SECRET_TAP) {
                                    val now = System.currentTimeMillis()
                                    if (now - lastTapTime < 500) secretTapCount++ else secretTapCount = 1
                                    lastTapTime = now
                                    if (secretTapCount >= 3) {
                                        secretTapCount = 0
                                        triggerForce(viewModel, list) {
                                            forceTriggered = true
                                            onForceReveal()
                                        }
                                    }
                                }
                            },
                        )
                    },
            )
            Spacer(Modifier.height(12.dp))
            // Display each item as a line of the "note"
            list.items.forEachIndexed { index, item ->
                Text(
                    text = item,
                    style = MaterialTheme.typography.bodyLarge,
                    color = MaterialTheme.colorScheme.onBackground,
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 2.dp),
                )
            }
        }
    }

    if (forceTriggered) {
        // brief toast confirming force triggered (magician-only feedback)
        LaunchedEffect(forceTriggered) {
            android.widget.Toast
                .makeText(context, "OK", android.widget.Toast.LENGTH_SHORT)
                .show()
        }
    }
}

private fun triggerForce(viewModel: DFBViewModel, list: NoteList, onDone: () -> Unit) {
    viewModel.performForce(list)
    onDone()
}
