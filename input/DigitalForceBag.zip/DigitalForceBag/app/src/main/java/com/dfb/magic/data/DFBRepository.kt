package com.dfb.magic.data

import kotlinx.coroutines.flow.Flow

/**
 * Single source of truth for the app's data. Wraps [PreferencesManager] and
 * exposes the operations the ViewModels need.
 */
class DFBRepository(private val prefs: PreferencesManager) {

    val listsFlow: Flow<List<NoteList>> = prefs.listsFlow
    val settingsFlow: Flow<AppSettings> = prefs.settingsFlow

    suspend fun ensureInitialized() = prefs.ensureInitialized()

    // ---- Lists CRUD ----
    suspend fun getLists(): List<NoteList> = kotlinx.coroutines.flow.first(listsFlow)

    suspend fun saveLists(lists: List<NoteList>) = prefs.saveLists(lists)

    suspend fun addList(title: String, items: List<String>, forcedIndex: Int = 0): String {
        val now = System.currentTimeMillis()
        val list = NoteList(
            title = title,
            items = items,
            forcedIndex = forcedIndex,
            createdAt = now,
            updatedAt = now,
        )
        val current = kotlinx.coroutines.flow.first(listsFlow).toMutableList()
        current.add(list)
        prefs.saveLists(current)
        return list.id
    }

    suspend fun updateList(updated: NoteList) {
        val current = kotlinx.coroutines.flow.first(listsFlow).toMutableList()
        val idx = current.indexOfFirst { it.id == updated.id }
        if (idx >= 0) {
            current[idx] = updated.copy(updatedAt = System.currentTimeMillis())
            prefs.saveLists(current)
        }
    }

    suspend fun deleteList(id: String): Boolean {
        val current = kotlinx.coroutines.flow.first(listsFlow).toMutableList()
        if (current.size <= 1) return false
        val removed = current.removeAll { it.id == id }
        if (removed) prefs.saveLists(current)
        return removed
    }

    suspend fun setForcedItem(listId: String, itemIndex: Int) {
        val current = kotlinx.coroutines.flow.first(listsFlow).toMutableList()
        val idx = current.indexOfFirst { it.id == listId }
        if (idx >= 0) {
            current[idx].forcedIndex = itemIndex
            current[idx].updatedAt = System.currentTimeMillis()
            prefs.saveLists(current)
        }
    }

    // ---- Settings ----
    suspend fun setMechanism(m: ForceMechanism) = prefs.setMechanism(m)
    suspend fun setLanguage(l: AppLanguage) = prefs.setLanguage(l)
    suspend fun setAppearance(a: AppAppearance) = prefs.setAppearance(a)
    suspend fun setPin(pin: String) = prefs.setPin(pin)
    suspend fun setProUnlocked(v: Boolean) = prefs.setProUnlocked(v)
    suspend fun setDiscreetMode(v: Boolean) = prefs.setDiscreetMode(v)
    suspend fun setLongPressDuration(ms: Long) = prefs.setLongPressDuration(ms)
}
