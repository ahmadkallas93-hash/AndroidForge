package com.dfb.magic.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ChevronRight
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.dfb.magic.ui.theme.DFBColors

private fun Color.luminance(): Float =
    0.299f * red + 0.587f * green + 0.114f * blue

/** True when the current Material color scheme is the light variant. */
@Composable
private fun isLightTheme(): Boolean =
    MaterialTheme.colorScheme.background.luminance() > 0.5f

@Composable
private fun secondaryText(): Color =
    if (isLightTheme()) DFBColors.iosSecondaryLight else DFBColors.iosSecondaryDark

@Composable
private fun separatorColor(): Color =
    if (isLightTheme()) DFBColors.iosSeparatorLight else DFBColors.iosSeparatorDark

/**
 * A row inside a grouped table (iOS Settings style).
 */
@Composable
fun IOSListRow(
    modifier: Modifier = Modifier,
    icon: (@Composable () -> Unit)? = null,
    iconBg: Color = DFBColors.iosBlue,
    title: String,
    subtitle: String? = null,
    value: String? = null,
    showChevron: Boolean = true,
    onClick: (() -> Unit)? = null,
    trailing: (@Composable () -> Unit)? = null,
) {
    Row(
        modifier = modifier
            .fillMaxWidth()
            .then(if (onClick != null) Modifier.clickable(onClick = onClick) else Modifier)
            .padding(horizontal = 16.dp, vertical = 11.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        if (icon != null) {
            Box(
                modifier = Modifier
                    .size(29.dp)
                    .clip(RoundedCornerShape(7.dp))
                    .background(iconBg),
                contentAlignment = Alignment.Center,
            ) {
                icon()
            }
            Spacer(Modifier.width(16.dp))
        }
        Column(modifier = Modifier.weight(1f)) {
            Text(
                text = title,
                style = MaterialTheme.typography.bodyLarge,
                color = MaterialTheme.colorScheme.onBackground,
            )
            if (subtitle != null) {
                Text(
                    text = subtitle,
                    style = MaterialTheme.typography.bodySmall,
                    color = secondaryText(),
                )
            }
        }
        if (value != null) {
            Text(
                text = value,
                style = MaterialTheme.typography.bodyLarge,
                color = secondaryText(),
            )
            Spacer(Modifier.width(4.dp))
        }
        if (trailing != null) trailing()
        if (showChevron && trailing == null) {
            Icon(
                imageVector = Icons.Filled.ChevronRight,
                contentDescription = null,
                tint = if (isLightTheme()) Color(0xFFC7C7CC) else Color(0xFF48484A),
                modifier = Modifier.size(16.dp),
            )
        }
    }
}

@Composable
fun IOSGroupedSection(
    title: String? = null,
    footer: String? = null,
    content: @Composable () -> Unit,
) {
    Column(modifier = Modifier.fillMaxWidth()) {
        if (title != null) {
            Text(
                text = title.uppercase(),
                style = MaterialTheme.typography.labelSmall,
                color = secondaryText(),
                modifier = Modifier.padding(start = 32.dp, end = 16.dp, bottom = 6.dp, top = 18.dp),
                fontSize = 13.sp,
            )
        }
        Surface(
            color = MaterialTheme.colorScheme.surface,
            modifier = Modifier
                .padding(horizontal = 16.dp)
                .clip(RoundedCornerShape(10.dp)),
        ) {
            Column { content() }
        }
        if (footer != null) {
            Text(
                text = footer,
                style = MaterialTheme.typography.bodySmall,
                color = secondaryText(),
                modifier = Modifier.padding(start = 32.dp, end = 32.dp, top = 6.dp),
            )
        }
    }
}

@Composable
fun IOSSeparator() {
    HorizontalDivider(
        modifier = Modifier.padding(start = 16.dp),
        thickness = 0.5.dp,
        color = separatorColor(),
    )
}
