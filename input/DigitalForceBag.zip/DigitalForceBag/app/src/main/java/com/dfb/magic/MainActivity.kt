package com.dfb.magic

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.core.splashscreen.SplashScreen.Companion.installSplashScreen
import androidx.lifecycle.lifecycleScope
import com.dfb.magic.data.AppAppearance
import com.dfb.magic.data.AppLanguage
import com.dfb.magic.data.PreferencesManager
import com.dfb.magic.ui.navigation.DFBNavHost
import com.dfb.magic.ui.theme.DFBTheme
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch
import java.util.Locale

class MainActivity : ComponentActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        installSplashScreen()
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        // Apply the saved locale synchronously before the UI is composed so the
        // first frame already uses the correct language.
        lifecycleScope.launch {
            val lang = PreferencesManager(applicationContext).settingsFlow.first().language
            applyLocale(lang)
        }
        setContent {
            val prefs = PreferencesManager(applicationContext)
            val settings by prefs.settingsFlow.collectAsState(initial = com.dfb.magic.data.AppSettings())
            val dark = when (settings.appearance) {
                AppAppearance.SYSTEM -> isSystemInDarkTheme()
                AppAppearance.LIGHT -> false
                AppAppearance.DARK -> true
            }
            DFBTheme(darkTheme = dark) {
                DFBNavHost()
            }
        }
    }

    private fun applyLocale(lang: AppLanguage) {
        val locale = when (lang) {
            AppLanguage.ENGLISH -> Locale.ENGLISH
            AppLanguage.ARABIC -> Locale("ar")
            AppLanguage.SYSTEM -> Locale.getDefault()
        }
        val config = resources.configuration
        config.setLocale(locale)
        @Suppress("DEPRECATION")
        resources.updateConfiguration(config, resources.displayMetrics)
    }
}
