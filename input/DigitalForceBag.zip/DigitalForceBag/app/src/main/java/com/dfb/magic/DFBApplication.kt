package com.dfb.magic

import android.app.Application
import com.dfb.magic.data.DFBRepository
import com.dfb.magic.data.PreferencesManager

class DFBApplication : Application() {
    lateinit var repository: DFBRepository
        private set

    override fun onCreate() {
        super.onCreate()
        repository = DFBRepository(PreferencesManager(this))
    }
}
