package com.dfb.magic.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.dfb.magic.ui.theme.DFBColors
import com.dfb.magic.ui.viewmodel.DFBViewModel

@Composable
fun ResultScreen(
    viewModel: DFBViewModel,
    onPickAnother: () -> Unit,
    onClose: () -> Unit,
) {
    val result by viewModel.forceResult.collectAsState()
    val context = LocalContext.current
    var revealed by remember { mutableStateOf(false) }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Text(
                        text = context.getString(com.dfb.magic.R.string.your_selection),
                        fontWeight = FontWeight.SemiBold,
                    )
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.background,
                ),
            )
        },
        containerColor = MaterialTheme.colorScheme.background,
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
        ) {
            Spacer(Modifier.height(40.dp))

            Text(
                text = result.listTitle,
                style = MaterialTheme.typography.titleMedium,
                color = DFBColors.iosSecondaryLight,
                textAlign = TextAlign.Center,
            )
            Spacer(Modifier.height(40.dp))

            // Big card with the revealed item
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(16.dp))
                    .background(MaterialTheme.colorScheme.surface)
                    .clickable { revealed = !revealed }
                    .padding(28.dp),
                contentAlignment = Alignment.Center,
            ) {
                AnimatedVisibility(visible = revealed, enter = fadeIn(), exit = fadeOut()) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text(
                            text = result.item,
                            style = MaterialTheme.typography.headlineMedium,
                            fontWeight = FontWeight.Bold,
                            textAlign = TextAlign.Center,
                        )
                        if (result.secondItem != null) {
                            Spacer(Modifier.height(12.dp))
                            Text(
                                text = result.secondItem,
                                style = MaterialTheme.typography.titleMedium,
                                color = DFBColors.iosAccent,
                                textAlign = TextAlign.Center,
                            )
                        }
                    }
                }
                AnimatedVisibility(visible = !revealed, enter = fadeIn(), exit = fadeOut()) {
                    Text(
                        text = context.getString(com.dfb.magic.R.string.reveal_again),
                        style = MaterialTheme.typography.bodyLarge,
                        color = DFBColors.iosSecondaryLight,
                        textAlign = TextAlign.Center,
                    )
                }
            }

            Spacer(Modifier.weight(1f))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(12.dp),
            ) {
                OutlinedButton(
                    onClick = { revealed = !revealed },
                    modifier = Modifier.weight(1f),
                ) {
                    Text(context.getString(com.dfb.magic.R.string.reveal_again))
                }
                Button(
                    onClick = onPickAnother,
                    modifier = Modifier.weight(1f),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = DFBColors.iosAccent,
                        contentColor = androidx.compose.ui.graphics.Color.Black,
                    ),
                ) {
                    Text(context.getString(com.dfb.magic.R.string.new_pick))
                }
            }

            TextButton(onClick = onClose) {
                Text("Close", color = DFBColors.iosSecondaryLight)
            }
        }
    }
}
