package com.dfb.magic.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.dfb.magic.data.NoteList
import com.dfb.magic.ui.theme.DFBColors
import com.dfb.magic.ui.viewmodel.DFBViewModel
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun NotesListScreen(
    viewModel: DFBViewModel,
    onNoteClick: (NoteList) -> Unit,
    onNewNote: () -> Unit,
    onOpenSettings: () -> Unit,
    onOpenSecret: () -> Unit,
) {
    val lists by viewModel.lists.collectAsState()
    val settings by viewModel.settings.collectAsState()
    val context = LocalContext.current
    var query by remember { mutableStateOf("") }
    var secretTapCount by remember { mutableStateOf(0) }
    var lastTapTime by remember { mutableStateOf(0L) }
    var showForceToast by remember { mutableStateOf<String?>(null) }

    val filtered = if (query.isBlank()) lists else lists.filter {
        it.title.contains(query, ignoreCase = true) ||
            it.items.any { item -> item.contains(query, ignoreCase = true) }
    }

    Scaffold(
        topBar = {
            Column {
                LargeTopAppBar(
                    title = {
                        Text(
                            text = context.getString(
                                com.dfb.magic.R.string.notes_header
                            ),
                            fontWeight = FontWeight.Bold,
                        )
                    },
                    actions = {
                        IconButton(onClick = onOpenSettings) {
                            Icon(
                                imageVector = androidx.compose.material.icons.Icons.Filled.Edit,
                                contentDescription = context.getString(
                                    com.dfb.magic.R.string.edit_list
                                ),
                            )
                        }
                    },
                    colors = TopAppBarDefaults.largeTopAppBarColors(
                        containerColor = MaterialTheme.colorScheme.background,
                    ),
                )
            }
        },
        floatingActionButton = {
            ExtendedFloatingActionButton(
                onClick = onNewNote,
                containerColor = DFBColors.iosAccent,
                contentColor = Color.Black,
                icon = { Icon(Icons.Filled.Edit, contentDescription = null) },
                text = { Text(context.getString(com.dfb.magic.R.string.new_list)) },
            )
        },
        containerColor = MaterialTheme.colorScheme.background,
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding),
        ) {
            // Search bar
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 8.dp)
                    .clip(RoundedCornerShape(10.dp))
                    .background(if (MaterialTheme.colorScheme.background.luminance() > 0.5f)
                        DFBColors.iosSearchBgLight else DFBColors.iosSearchBgDark)
                    .padding(horizontal = 8.dp, vertical = 7.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Icon(
                    imageVector = Icons.Filled.Search,
                    contentDescription = null,
                    tint = if (MaterialTheme.colorScheme.background.luminance() > 0.5f)
                        DFBColors.iosSecondaryLight else DFBColors.iosSecondaryDark,
                    modifier = Modifier.size(18.dp),
                )
                Spacer(Modifier.width(6.dp))
                TextField(
                    value = query,
                    onValueChange = { query = it },
                    placeholder = {
                        Text(
                            text = context.getString(com.dfb.magic.R.string.search_placeholder),
                            color = if (MaterialTheme.colorScheme.background.luminance() > 0.5f)
                                DFBColors.iosSecondaryLight else DFBColors.iosSecondaryDark,
                        )
                    },
                    singleLine = true,
                    modifier = Modifier.weight(1f),
                    colors = TextFieldDefaults.colors(
                        focusedContainerColor = Color.Transparent,
                        unfocusedContainerColor = Color.Transparent,
                        disabledContainerColor = Color.Transparent,
                        focusedIndicatorColor = Color.Transparent,
                        unfocusedIndicatorColor = Color.Transparent,
                    ),
                    textStyle = MaterialTheme.typography.bodyLarge,
                )
            }

            val today = filtered.filter { isToday(it.updatedAt) }
            val yesterday = filtered.filter { isYesterday(it.updatedAt) }

            LazyColumn(
                modifier = Modifier.fillMaxSize(),
                contentPadding = PaddingValues(bottom = 80.dp),
            ) {
                if (today.isNotEmpty()) {
                    item { SectionHeader(context.getString(com.dfb.magic.R.string.today)) }
                    items(today) { note ->
                        NoteRow(note = note, onClick = { onNoteClick(note) })
                    }
                }
                if (yesterday.isNotEmpty()) {
                    item { Spacer(Modifier.height(12.dp)) }
                    item { SectionHeader(context.getString(com.dfb.magic.R.string.yesterday)) }
                    items(yesterday) { note ->
                        NoteRow(note = note, onClick = { onNoteClick(note) })
                    }
                }
                if (today.isEmpty() && yesterday.isEmpty()) {
                    item { Spacer(Modifier.height(12.dp)) }
                    items(filtered) { note ->
                        NoteRow(note = note, onClick = { onNoteClick(note) })
                    }
                }
                if (filtered.isEmpty()) {
                    item {
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(top = 80.dp),
                            contentAlignment = Alignment.Center,
                        ) {
                            Text(
                                text = context.getString(com.dfb.magic.R.string.no_notes),
                                color = if (MaterialTheme.colorScheme.background.luminance() > 0.5f)
                                    DFBColors.iosSecondaryLight else DFBColors.iosSecondaryDark,
                                fontSize = 15.sp,
                            )
                        }
                    }
                }
            }
        }
    }

    // Discreet-mode secret tap detector on the title area (5 quick taps)
    LaunchedEffect(secretTapCount) {
        if (secretTapCount >= 5 && settings.discreetMode) {
            onOpenSecret()
            secretTapCount = 0
        }
    }

    showForceToast?.let { msg ->
        LaunchedEffect(msg) {
            android.widget.Toast.makeText(context, msg, android.widget.Toast.LENGTH_SHORT).show()
            showForceToast = null
        }
    }
}

@Composable
private fun SectionHeader(title: String) {
    Text(
        text = title,
        style = MaterialTheme.typography.labelSmall,
        color = if (MaterialTheme.colorScheme.background.luminance() > 0.5f)
            DFBColors.iosSecondaryLight else DFBColors.iosSecondaryDark,
        modifier = Modifier.padding(start = 32.dp, top = 16.dp, bottom = 4.dp),
        fontSize = 13.sp,
    )
}

@Composable
private fun NoteRow(note: NoteList, onClick: () -> Unit) {
    val dateFmt = remember { SimpleDateFormat("h:mm a", Locale.getDefault()) }
    Surface(
        color = MaterialTheme.colorScheme.surface,
        modifier = Modifier
            .padding(horizontal = 16.dp, vertical = 1.dp)
            .clip(RoundedCornerShape(10.dp))
            .combinedClickable(onClick = onClick),
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 10.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = note.title,
                    style = MaterialTheme.typography.bodyLarge,
                    fontWeight = FontWeight.SemiBold,
                    color = MaterialTheme.colorScheme.onSurface,
                    maxLines = 1,
                )
                Spacer(Modifier.height(2.dp))
                Text(
                    text = note.items.firstOrNull() ?: "",
                    style = MaterialTheme.typography.bodyMedium,
                    color = if (MaterialTheme.colorScheme.background.luminance() > 0.5f)
                        DFBColors.iosSecondaryLight else DFBColors.iosSecondaryDark,
                    maxLines = 1,
                )
            }
            Text(
                text = dateFmt.format(Date(note.updatedAt)),
                style = MaterialTheme.typography.bodySmall,
                color = if (MaterialTheme.colorScheme.background.luminance() > 0.5f)
                    DFBColors.iosSecondaryLight else DFBColors.iosSecondaryDark,
            )
        }
    }
}

private fun isToday(timestamp: Long): Boolean {
    val now = System.currentTimeMillis()
    val oneDay = 24 * 60 * 60 * 1000L
    return (now - timestamp) < oneDay
}

private fun isYesterday(timestamp: Long): Boolean {
    val now = System.currentTimeMillis()
    val oneDay = 24 * 60 * 60 * 1000L
    return (now - timestamp) in oneDay..(2 * oneDay)
}

private fun Color.luminance(): Float =
    0.299f * red + 0.587f * green + 0.114f * blue
