package com.dfb.magic.data

/** Pre-loaded sample lists, mimicking the original DFB which ships with 5+ sample categories. */
object SampleData {

    fun defaultLists(): List<NoteList> {
        val now = System.currentTimeMillis()
        return listOf(
            NoteList(
                title = "Playing Cards",
                items = playingCards(),
                forcedIndex = 13, // Ace of Spades
                createdAt = now - 1000,
                updatedAt = now - 1000,
            ),
            NoteList(
                title = "World Cities",
                items = cities(),
                forcedIndex = 4, // Paris
                createdAt = now - 2000,
                updatedAt = now - 2000,
            ),
            NoteList(
                title = "Movie Titles",
                items = movies(),
                forcedIndex = 2, // The Matrix
                createdAt = now - 3000,
                updatedAt = now - 3000,
            ),
            NoteList(
                title = "Vegetables",
                items = vegetables(),
                forcedIndex = 0, // Carrot
                createdAt = now - 4000,
                updatedAt = now - 4000,
            ),
            NoteList(
                title = "Numbers 1-100",
                items = (1..100).map { it.toString() },
                forcedIndex = 36, // 37
                createdAt = now - 5000,
                updatedAt = now - 5000,
            ),
            NoteList(
                title = "Colors",
                items = colors(),
                forcedIndex = 1, // Red
                createdAt = now - 6000,
                updatedAt = now - 6000,
            ),
            NoteList(
                title = "Countries",
                items = countries(),
                forcedIndex = 7, // Japan
                createdAt = now - 7000,
                updatedAt = now - 7000,
            ),
            NoteList(
                title = "Animals",
                items = animals(),
                forcedIndex = 3, // Lion
                createdAt = now - 8000,
                updatedAt = now - 8000,
            ),
        )
    }

    private fun playingCards(): List<String> {
        val suits = listOf("Spades", "Hearts", "Diamonds", "Clubs")
        val ranks = listOf(
            "Ace", "2", "3", "4", "5", "6", "7", "8", "9", "10", "Jack", "Queen", "King"
        )
        return ranks.flatMap { r -> suits.map { s -> "$r of $s" } }
    }

    private fun cities(): List<String> = listOf(
        "New York", "London", "Tokyo", "Dubai", "Paris", "Berlin", "Sydney",
        "Cairo", "Rome", "Toronto", "Singapore", "Istanbul", "Madrid",
        "Seoul", "Bangkok", "Moscow", "Riyadh", "Lisbon", "Vienna", "Athens",
        "Mumbai", "Beijing", "Hong Kong", "Barcelona", "Amsterdam",
        "Stockholm", "Copenhagen", "Dublin", "Prague", "Budapest",
        "Warsaw", "Helsinki", "Oslo", "Brussels", "Zurich", "Munich",
        "Hamburg", "Frankfurt", "Milan", "Naples", "Venice", "Florence",
        "Marseille", "Lyon", "Nice", "Edinburgh", "Manchester", "Glasgow",
        "Liverpool", "Birmingham", "Leeds", "Sheffield", "Bristol",
        "Cardiff", "Belfast", "Montreal", "Vancouver", "Ottawa", "Calgary",
        "Edmonton", "Seattle", "Boston", "Chicago", "Miami", "Dallas",
        "Houston", "Denver", "Phoenix", "Atlanta", "San Francisco",
        "Los Angeles", "San Diego", "Las Vegas", "Portland", "Detroit",
        "Minneapolis", "Philadelphia", "Washington", "Baltimore",
        "Auckland", "Wellington", "Melbourne", "Brisbane", "Perth", "Adelaide",
        "Canberra", "Hobart", "Doha", "Amman", "Beirut", "Damascus",
        "Baghdad", "Tehran", "Baku", "Tbilisi", "Yerevan", "Almaty",
        "Tashkent", "Casablanca", "Tunis", "Algiers", "Nairobi",
        "Cape Town", "Lagos", "Accra", "Addis Ababa",
    )

    private fun movies(): List<String> = listOf(
        "The Godfather", "Pulp Fiction", "The Matrix", "Inception", "Interstellar",
        "Titanic", "Avatar", "The Dark Knight", "Fight Club", "Forrest Gump",
        "Gladiator", "Braveheart", "The Shawshank Redemption", "Casablanca",
        "The Wizard of Oz", "Star Wars", "Jurassic Park", "The Lion King",
        "Toy Story", "Shrek", "Frozen", "Finding Nemo", "Up", "WALL-E",
        "The Avengers", "Iron Man", "Spider-Man", "Batman Begins",
        "Man of Steel", "Wonder Woman", "Black Panther", "Doctor Strange",
        "Thor", "Captain America", "Guardians of the Galaxy", "Ant-Man",
        "Deadpool", "Logan", "Joker", "Dune", "Blade Runner", "Alien",
        "The Terminator", "Predator", "Die Hard", "Lethal Weapon",
        "Mission Impossible", "James Bond", "Jason Bourne", "John Wick",
        "The Lord of the Rings", "The Hobbit", "Harry Potter", "Twilight",
        "The Hunger Games", "Divergent", "The Maze Runner", "Percy Jackson",
        "Narnia", "Eragon", "Star Trek", "The Princess Bride",
        "The Sound of Music", "Singin' in the Rain", "Gone with the Wind",
        "Citizen Kane", "Vertigo", "Psycho", "Rear Window", "North by Northwest",
        "Goodfellas", "The Departed", "Scarface", "The Untouchables",
        "Once Upon a Time in America", "The Good the Bad and the Ugly",
        "For a Few Dollars More", "A Fistful of Dollars", "Unforgiven",
        "The Great Escape", "The Bridge on the River Kwai", "Lawrence of Arabia",
        "Apocalypse Now", "Platoon", "Full Metal Jacket", "Saving Private Ryan",
        "Schindler's List", "The Pianist", "Life is Beautiful", "Amelie",
        "Cinema Paradiso", "La Dolce Vita", "8 1/2", "Bicycle Thieves",
        "Seven Samurai", "Rashomon", "Yojimbo", "Spirited Away", "Akira",
        "Your Name", "Princess Mononoke", "Howl's Moving Castle",
    )

    private fun vegetables(): List<String> = listOf(
        "Carrot", "Potato", "Onion", "Garlic", "Cabbage", "Lettuce", "Spinach",
        "Broccoli", "Cauliflower", "Cucumber", "Tomato", "Pepper", "Eggplant",
        "Zucchini", "Pumpkin", "Squash", "Corn", "Peas", "Beans", "Celery",
        "Radish", "Beet", "Turnip", "Parsnip", "Rutabaga", "Kale", "Chard",
        "Arugula", "Fennel", "Leek", "Shallot", "Scallion", "Chive",
        "Asparagus", "Artichoke", "Brussels Sprouts", "Okra", "Bok Choy",
        "Watercress", "Endive", "Radiccio", "Jicama", "Yam", "Sweet Potato",
        "Cassava", "Taro", "Lotus Root", "Bamboo Shoots", "Water Chestnut",
        "Daikon", "Bitter Melon", "Kohlrabi", "Celeriac", "Salsify",
        "Sunchoke", "Mushroom", "Truffle", "Morel", "Chanterelle",
        "Portobello", "Shiitake", "Oyster Mushroom", "Enoki", "Maitake",
        "Capers", "Olives", "Sun-dried Tomato", "Pickled Cucumber",
        "Sauerkraut", "Kimchi", "Pickled Beets", "Pickled Onion",
        "Pickled Pepper", "Pickled Garlic", "Pickled Radish",
        "Pickled Eggplant", "Pickled Cabbage", "Pickled Carrot",
        "Pickled Beans", "Pickled Cauliflower", "Pickled Mushroom",
        "Pickled Okra", "Pickled Asparagus", "Pickled Celery",
        "Pickled Turnip", "Pickled Kohlrabi", "Pickled Pumpkin",
        "Pickled Squash", "Pickled Zucchini", "Pickled Tomato",
        "Pickled Artichoke", "Pickled Brussels Sprouts",
        "Pickled Chard", "Pickled Kale", "Pickled Spinach",
        "Pickled Lettuce", "Pickled Endive", "Pickled Radiccio",
        "Pickled Watercress", "Pickled Fennel", "Pickled Leek",
    )

    private fun colors(): List<String> = listOf(
        "Red", "Orange", "Yellow", "Green", "Blue", "Indigo", "Violet",
        "Purple", "Pink", "Brown", "Black", "White", "Gray", "Silver",
        "Gold", "Copper", "Bronze", "Maroon", "Crimson", "Scarlet",
        "Coral", "Salmon", "Peach", "Apricot", "Amber", "Mustard",
        "Lime", "Olive", "Forest", "Mint", "Teal", "Cyan", "Turquoise",
        "Azure", "Navy", "Cobalt", "Periwinkle", "Lavender", "Lilac",
        "Plum", "Magenta", "Fuchsia", "Rose", "Ruby", "Burgundy",
        "Wine", "Cherry", "Mahogany", "Tan", "Beige", "Ivory", "Cream",
        "Pearl", "Snow", "Ivory", "Khaki", "Chocolate", "Coffee",
        "Espresso", "Mocha", "Caramel", "Honey", "Sand", "Stone",
        "Slate", "Charcoal", "Onyx", "Ebony", "Midnight", "Sky Blue",
        "Powder Blue", "Baby Blue", "Royal Blue", "Electric Blue",
        "Ocean Blue", "Sea Green", "Spring Green", "Jade", "Emerald",
        "Mint Green", "Sage", "Pistachio", "Avocado", "Chartreuse",
        "Goldenrod", "Daffodil", "Lemon", "Banana", "Tangerine",
        "Pumpkin", "Burnt Orange", "Rust", "Brick", "Tomato",
        "Watermelon", "Bubblegum", "Cotton Candy", "Hot Pink",
        "Blush", "Mauve", "Dusty Rose", "Antique Rose", "Petunia",
        "Orchid", "Amethyst", "Grape", "Eggplant", "Royal Purple",
        "Imperial Purple", "Tyrian Purple",
    )

    private fun countries(): List<String> = listOf(
        "United States", "United Kingdom", "France", "Germany", "Italy",
        "Spain", "Portugal", "Netherlands", "Belgium", "Switzerland",
        "Austria", "Hungary", "Czech Republic", "Poland", "Slovakia",
        "Slovenia", "Croatia", "Serbia", "Bosnia", "Montenegro",
        "Albania", "Greece", "Bulgaria", "Romania", "Moldova",
        "Ukraine", "Belarus", "Lithuania", "Latvia", "Estonia",
        "Finland", "Sweden", "Norway", "Denmark", "Iceland",
        "Ireland", "Luxembourg", "Liechtenstein", "Monaco", "Andorra",
        "San Marino", "Vatican City", "Malta", "Cyprus", "Turkey",
        "Russia", "Georgia", "Armenia", "Azerbaijan", "Kazakhstan",
        "Uzbekistan", "Turkmenistan", "Kyrgyzstan", "Tajikistan",
        "China", "Japan", "South Korea", "North Korea", "Mongolia",
        "Taiwan", "Hong Kong", "Macau", "Vietnam", "Laos", "Cambodia",
        "Thailand", "Myanmar", "Malaysia", "Singapore", "Indonesia",
        "Philippines", "Brunei", "East Timor", "India", "Pakistan",
        "Bangladesh", "Sri Lanka", "Maldives", "Nepal", "Bhutan",
        "Afghanistan", "Iran", "Iraq", "Syria", "Lebanon", "Jordan",
        "Israel", "Palestine", "Saudi Arabia", "Yemen", "Oman",
        "United Arab Emirates", "Qatar", "Bahrain", "Kuwait", "Egypt",
        "Libya", "Tunisia", "Algeria", "Morocco", "Sudan", "South Sudan",
    )

    private fun animals(): List<String> = listOf(
        "Lion", "Tiger", "Bear", "Wolf", "Fox", "Deer", "Horse", "Cow",
        "Sheep", "Goat", "Pig", "Chicken", "Duck", "Goose", "Turkey",
        "Rabbit", "Squirrel", "Chipmunk", "Beaver", "Hedgehog",
        "Mole", "Bat", "Raccoon", "Skunk", "Opossum", "Otter", "Weasel",
        "Ferret", "Mink", "Ermine", "Martens", "Badger", "Wolverine",
        "Coyote", "Jackal", "Hyena", "Leopard", "Cheetah", "Jaguar",
        "Panther", "Cougar", "Lynx", "Bobcat", "Ocelot", "Serval",
        "Caracal", "Elephant", "Rhino", "Hippo", "Giraffe", "Zebra",
        "Buffalo", "Bison", "Antelope", "Gazelle", "Impala", "Wildebeest",
        "Moose", "Elk", "Reindeer", "Caribou", "Camel", "Llama", "Alpaca",
        "Donkey", "Mule", "Dog", "Cat", "Hamster", "Guinea Pig", "Gerbil",
        "Rat", "Mouse", "Monkey", "Ape", "Chimpanzee", "Gorilla",
        "Orangutan", "Baboon", "Mandrill", "Lemur", "Kangaroo", "Koala",
        "Wallaby", "Wombat", "Platypus", "Echidna", "Ostrich", "Emu",
        "Cassowary", "Rhea", "Penguin", "Pelican", "Stork", "Heron",
        "Crane", "Flamingo", "Swan", "Eagle", "Hawk", "Falcon", "Owl",
        "Parrot", "Crow", "Raven", "Magpie", "Pigeon", "Dove", "Sparrow",
    )
}
