# Add project specific ProGuard rules here.
-keep class com.dfb.magic.** { *; }
-keepattributes Signature
-keepattributes *Annotation*
-keep class com.google.gson.** { *; }
