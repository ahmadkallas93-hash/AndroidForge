# Digital Force Bag — تطبيق سحري للموبايل (Android)

> **تنبيه قانوني / Legal note**: هذا المشروع هو **نسخة تعليمية/شخصية** مستوحاة من فكرة تطبيق "Digital Force Bag" الشهير للساحرَين Nick Einhorn و Craig Squires (المطور Marc Kerstein). لا يستخدم أي شيفرة أو أصول من التطبيق الأصلي، ولا ينتحل علامته التجارية. الاسم "Notes" فقط هو الاسم الظاهر للمستخدم النهائي كجزء من التنكر، وليس اسم المنتج. تم بناء كل الكود من الصفر لأغراض التعلم والممارسة الشخصية.

This is a **from-scratch, educational Android clone** of the *concept* behind "Digital Force Bag" (DFB) — a magic utility that disguises itself as the iOS Notes app and lets a magician *force* any item from a list of up to 100 without the spectator ever suspecting a phone is involved. No original code, assets or trademarks are reused.

---

## ✨ الميزات | Features

- 🎭 **تنكر كامل كتطبيق الملاحظات** — واجهة طبق الأصل لمظهر iOS Notes (العنوان الأصفر، البطاقات البيضاء، الخطوط، الفواصل).
- 🪄 **إجبار سري للعنصر** — يختار الساحر العنصر المُجبَر من قائمة، ويظن المتفرّج أنه اختاره بنفسه.
- 🎯 **ثلاث آليات للإجبار**:
  - **ضغط مطوّل** (افتراضي) — ضغط طويل داخل الملاحظة.
  - **نقرات سرية** — 3 نقرات سريعة على متن الملاحظة.
  - **زر الصوت** — زر خفض الصوت (يتطلب تفعيلًا من الإعدادات).
- 🗂️ **8 قوائم جاهزة**: أوراق اللعب (52)، مدن العالم، عناوين الأفلام، الخضروات، أرقام 1-100، الألوان، الدول، الحيوانات.
- ✏️ **محرر قوائم كامل** — إضافة/حذف/تعديل القوائم والعناصر، وتعيين العنصر المُجبَر.
- 🔐 **شاشة سرية محمية برمز PIN** (الافتراضي `2580` — يُنصح بتغييره).
- 👻 **الوضع المتخفي (Discreet Mode)** — يخفي القوائم السرية؛ لإظهارها انقر على العنوان "Notes" 5 مرات بسرعة.
- 🌗 **وضع فاتح/داكن/حسب النظام**.
- 🌍 **ثنائي اللغة (عربي/إنجليزي)** مع دعم RTL كامل. تغيير اللغة من الإعدادات يُطبّق عند إعادة تشغيل التطبيق.
- 💾 **حفظ تلقائي** عبر DataStore (لا حاجة للإنترنت أو بلوتوث أو NFC).

---

## 🛠️ التقنيات | Tech Stack

| الطبقة | المكتبة |
| --- | --- |
| اللغة | Kotlin 2.0.20 |
| UI | Jetpack Compose + Material 3 (BOM 2024.09) |
| التنقل | Navigation-Compose 2.8 |
| التخزين | DataStore Preferences + Gson |
| البناء | Gradle 8.9 + AGP 8.5.2 (Kotlin DSL) |
| الحد الأدنى | Android 8.0 (API 26) |
| الهدف | Android 14 (API 34) |

---

## 📁 بنية المشروع | Project structure

```
DigitalForceBag/
├── settings.gradle.kts
├── build.gradle.kts
├── gradle.properties
├── gradle/
│   ├── libs.versions.toml        # version catalog
│   └── wrapper/gradle-wrapper.properties
├── gradlew, gradlew.bat
└── app/
    ├── build.gradle.kts
    ├── proguard-rules.pro
    └── src/main/
        ├── AndroidManifest.xml
        ├── java/com/dfb/magic/
        │   ├── DFBApplication.kt
        │   ├── MainActivity.kt
        │   ├── data/
        │   │   ├── Models.kt
        │   │   ├── SampleData.kt
        │   │   ├── PreferencesManager.kt
        │   │   └── DFBRepository.kt
        │   └── ui/
        │       ├── theme/ (Color.kt, Type.kt, Theme.kt)
        │       ├── navigation/ (Screen.kt, NavHost.kt)
        │       ├── viewmodel/ (DFBViewModel.kt)
        │       └── screens/ (NotesList, NoteView, Result, SecretConfig,
        │                     Settings, About, EditListDialog, Components)
        └── res/
            ├── values/ (strings.xml, colors.xml, themes.xml)
            ├── values-ar/ (strings.xml)
            ├── drawable/ic_launcher_foreground.xml
            ├── mipmap-*/ ic_launcher.png (+ round, foreground)
            └── xml/ (backup_rules, data_extraction_rules)
```

---

## ▶️ كيفية البناء | How to build

### المتطلبات | Requirements
- **JDK 17**
- **Android Studio Ladybug (2024.2.1) أو أحدث** (يأتي مع Gradle 8.9 و AGP 8.5.2)
- **SDK Platform Android 14 (API 34)** + **Build-Tools 34.0.0**

### الطريقة 1: من Android Studio (الأسهل)
1. `File → Open` ثم اختر مجلد `DigitalForceBag/`.
2. انتظر مزامنة Gradle (يُحمل Wrapper تلقائيًا).
3. وصّل جهاز Android أو شغّل المحاكي.
4. اضغط **Run ▶** أو `Shift+F10`.

### الطريقة 2: من سطر الأوامر
```bash
cd DigitalForceBag
./gradlew assembleDebug      # → app/build/outputs/apk/debug/app-debug.apk
./gradlew installDebug       # يثبت على جهاز موصول
./gradlew assembleRelease    # نسخة الإصدار (تتطلب توقيعًا)
```

> 💡 على ويندوز استبدل `./gradlew` بـ `gradlew.bat`.

### لتوقيع نسخة الإصدار
أضف ملف `keystore.properties` في جذر المشروع:
```properties
storeFile=your_release.jks
storePassword=********
keyAlias=release
keyPassword=********
```
ثم أضف إلى `app/build.gradle.kts` كتلة `signingConfigs` (مثال مشروح في ملف البناء).

---

## 🎩 كيفية الاستخدام | Usage

1. افتح التطبيق — يظهر كأنه تطبيق **Notes** عادي بقوائم جاهزة.
2. اضغط أي قائمة لفتحها (مثل فتح ملاحظة عادية).
3. **الإجبار** (آلية الضغط المطوّل الافتراضية): اضغط ضغطًا طويلًا على متن الملاحظة → يُنقلك لشاشة الكشف.
4. شاشة الكشف تعرض العنصر المُجبَر فقط عند النقر عليها (للحفاظ على عنصر المفاجأة).

**للوصول للوضع السري:**
- افتح الإعدادات من زر القلم في الأعلى.
- أو فعّل **الوضع المتخفي** ثم انقر على عنوان "Notes" 5 مرات بسرعة من القائمة الرئيسية → يطلب رمز PIN (`2580`).

**في الوضع السري:**
- عدّل القوائم والعناصر، وعيّن العنصر المُجبَر (★).
- بدّل آلية الإجبار.
- فعّل المزايا الاحترافية (إجبار ثانٍ، قوائم غير محدودة).

---

## 🔒 الأمان | Security notes

- لا يستخدم التطبيق أي اتصال شبكي أو بلوتوث أو NFC — كل شيء يعمل محليًا.
- رمز PIN الافتراضي `2580` يجب تغييره قبل العرض العام (من شاشة الإعدادات السرية).
- البيانات محفوظة في DataStore مشفّرة فقط على الأجهزة المدعومة.

---

## ⚠️ إخلاء مسؤولية | Disclaimer

هذا المشروع لأغراض **تعليمية وترفيهية** فقط. لا يدّعي أي ارتباط بالمنتج الأصلي أو مُطوّريه. احترم حقوق الملكية الفكرية للأصل، واستعمل هذه النسخة لممارسة المهارات السحرية على مسؤوليتك الخاصة.
