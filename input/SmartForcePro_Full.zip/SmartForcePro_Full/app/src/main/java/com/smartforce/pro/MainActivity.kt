package com.smartforce.pro

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp

private val categories = listOf("رقم", "كلمة", "دولة", "لون", "اسم", "قائمة مخصصة")

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { SmartForceApp() }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SmartForceApp() {
    val context = LocalContext.current
    val store = remember { RoutineStore(context) }
    var routines by remember { mutableStateOf(store.all()) }
    var active by remember { mutableStateOf<ForceRoutine?>(null) }
    var page by remember { mutableStateOf("home") }
    var pinEntry by remember { mutableStateOf("") }
    var pinError by remember { mutableStateOf("") }

    var title by remember { mutableStateOf("") }
    var category by remember { mutableStateOf("دولة") }
    var target by remember { mutableStateOf("") }
    var itemsText by remember { mutableStateOf("مصر, اليابان, فرنسا, إيطاليا, البرازيل, كندا, الهند, أستراليا") }
    var pin by remember { mutableStateOf("2580") }
    var videoUri by remember { mutableStateOf("") }
    var imageUri by remember { mutableStateOf("") }
    var spectatorChoice by remember { mutableStateOf("") }
    var showReveal by remember { mutableStateOf(false) }
    var revealText by remember { mutableStateOf("") }

    val videoPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            runCatching { context.contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION) }
            videoUri = uri.toString()
        }
    }
    val imagePicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            runCatching { context.contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION) }
            imageUri = uri.toString()
        }
    }

    fun resetEditor() {
        active = null; title = ""; category = "دولة"; target = ""
        itemsText = "مصر, اليابان, فرنسا, إيطاليا, البرازيل, كندا, الهند, أستراليا"
        pin = "2580"; videoUri = ""; imageUri = ""; page = "editor"
    }
    fun editRoutine(r: ForceRoutine) {
        active = r; title = r.title; category = r.category; target = r.target
        itemsText = r.items.joinToString(", "); pin = r.performerPin
        videoUri = r.videoUri; imageUri = r.imageUri; page = "editor"
    }
    fun launchUri(raw: String, mime: String) {
        if (raw.isBlank()) return
        val intent = Intent(Intent.ACTION_VIEW).apply {
            setDataAndType(Uri.parse(raw), mime)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        runCatching { context.startActivity(intent) }
    }

    MaterialTheme(colorScheme = darkColorScheme(
        primary = androidx.compose.ui.graphics.Color(0xFFB9A5FF),
        secondary = androidx.compose.ui.graphics.Color(0xFF80CBC4),
        background = androidx.compose.ui.graphics.Color(0xFF10121A),
        surface = androidx.compose.ui.graphics.Color(0xFF1B1E2B)
    )) {
        Scaffold(containerColor = MaterialTheme.colorScheme.background) { padding ->
            Column(
                Modifier.fillMaxSize().padding(padding).verticalScroll(rememberScrollState()).padding(18.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Text("SMART FORCE PRO", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
                Text("MENTALISM TOOLKIT • OFFLINE", color = MaterialTheme.colorScheme.secondary)

                when (page) {
                    "home" -> {
                        Text("روتيناتك", style = MaterialTheme.typography.titleLarge)
                        Button(onClick = { resetEditor() }, modifier = Modifier.fillMaxWidth()) { Text("إنشاء خدعة جديدة") }
                        if (routines.isEmpty()) Text("لا توجد خدع محفوظة بعد. أنشئ أول روتين.")
                        routines.forEach { r ->
                            Card(Modifier.fillMaxWidth()) {
                                Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                                    Text(r.title, style = MaterialTheme.typography.titleMedium)
                                    Text("${r.category} • ${r.items.size} عناصر", style = MaterialTheme.typography.bodySmall)
                                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                        Button(onClick = {
                                            active = r; spectatorChoice = ""; showReveal = false; page = "pin"
                                        }) { Text("فتح وضع الساحر") }
                                        OutlinedButton(onClick = { editRoutine(r) }) { Text("تعديل") }
                                        OutlinedButton(onClick = {
                                            store.delete(r.id); routines = store.all()
                                        }) { Text("حذف") }
                                    }
                                }
                            }
                        }
                    }
                    "editor" -> {
                        Text("إعداد الروتين", style = MaterialTheme.typography.titleLarge)
                        OutlinedTextField(title, { title = it }, label = { Text("اسم الخدعة") }, modifier = Modifier.fillMaxWidth())
                        Text("نوع الاختيار")
                        categories.forEach { c ->
                            Row {
                                RadioButton(selected = category == c, onClick = { category = c })
                                Text(c, modifier = Modifier.padding(top = 12.dp))
                            }
                        }
                        OutlinedTextField(target, { target = it }, label = { Text("النتيجة المستهدفة (سرية)") }, modifier = Modifier.fillMaxWidth())
                        if (category != "رقم") {
                            OutlinedTextField(
                                itemsText, { itemsText = it },
                                label = { Text("القائمة – افصل العناصر بفاصلة") },
                                minLines = 3, modifier = Modifier.fillMaxWidth()
                            )
                        }
                        OutlinedTextField(pin, { pin = it.filter(Char::isDigit).take(8) },
                            label = { Text("رمز دخول الساحر (4 إلى 8 أرقام)") }, modifier = Modifier.fillMaxWidth())
                        HorizontalDivider()
                        Text("ملفات الكشف")
                        Button(onClick = { videoPicker.launch(arrayOf("video/*")) }, modifier = Modifier.fillMaxWidth()) {
                            Text(if (videoUri.isBlank()) "اختيار فيديو التوقع" else "تغيير فيديو التوقع")
                        }
                        Text(if (videoUri.isBlank()) "لا يوجد فيديو" else "تم إرفاق فيديو")
                        OutlinedButton(onClick = { imagePicker.launch(arrayOf("image/*")) }, modifier = Modifier.fillMaxWidth()) {
                            Text(if (imageUri.isBlank()) "اختيار صورة التوقع" else "تغيير صورة التوقع")
                        }
                        Text(if (imageUri.isBlank()) "لا توجد صورة" else "تم إرفاق صورة")
                        Button(onClick = {
                            val list = if (category == "رقم") emptyList() else itemsText.split(",").map { it.trim() }.filter { it.isNotBlank() }.distinct()
                            val routine = ForceRoutine(
                                id = active?.id ?: RoutineStore.newId(),
                                title = title.trim(), category = category, items = list,
                                target = target.trim(), videoUri = videoUri, imageUri = imageUri,
                                performerPin = pin.ifBlank { "2580" }
                            )
                            val error = ForceEngine.validate(routine)
                            if (error == null && pin.length in 4..8) {
                                store.save(routine); routines = store.all(); page = "home"
                            } else {
                                revealText = error ?: "رمز PIN يجب أن يكون من 4 إلى 8 أرقام"
                                page = "validation"
                            }
                        }, modifier = Modifier.fillMaxWidth()) { Text("حفظ الروتين") }
                        OutlinedButton(onClick = { page = "home" }, modifier = Modifier.fillMaxWidth()) { Text("إلغاء") }
                    }
                    "validation" -> {
                        Text("تعذر الحفظ")
                        Text(revealText)
                        Button(onClick = { page = "editor" }) { Text("العودة") }
                    }
                    "pin" -> {
                        Text("دخول الساحر", style = MaterialTheme.typography.titleLarge)
                        Text("هذه الشاشة مخصصة للمؤدي فقط.")
                        OutlinedTextField(pinEntry, { pinEntry = it.filter(Char::isDigit).take(8) },
                            label = { Text("أدخل رمز PIN") }, modifier = Modifier.fillMaxWidth())
                        if (pinError.isNotBlank()) Text(pinError, color = MaterialTheme.colorScheme.error)
                        Button(onClick = {
                            if (pinEntry == active?.performerPin) {
                                page = "performer"; pinError = ""; pinEntry = ""
                            } else pinError = "رمز غير صحيح"
                        }, modifier = Modifier.fillMaxWidth()) { Text("دخول") }
                        OutlinedButton(onClick = { page = "home" }) { Text("رجوع") }
                    }
                    "performer" -> {
                        val r = active
                        if (r != null) {
                            Text("لوحة الساحر: ${r.title}", style = MaterialTheme.typography.titleLarge)
                            Text("النتيجة السرية: ${r.target}", color = MaterialTheme.colorScheme.primary)
                            Text("القائمة: ${r.items.joinToString(" • ")}")
                            Button(onClick = { page = "spectator"; showReveal = false; spectatorChoice = "" }, modifier = Modifier.fillMaxWidth()) {
                                Text("انتقال إلى وضع المتفرج")
                            }
                            OutlinedButton(onClick = { page = "home" }, modifier = Modifier.fillMaxWidth()) { Text("إنهاء الجلسة") }
                        }
                    }
                    "spectator" -> {
                        val r = active
                        if (r != null) {
                            Text("اختيارك", style = MaterialTheme.typography.headlineSmall)
                            Text("اختر عنصراً من القائمة.")
                            if (r.category == "رقم") {
                                OutlinedTextField(spectatorChoice, { spectatorChoice = it.filter(Char::isDigit).take(6) },
                                    label = { Text("اكتب الرقم الذي اخترته") }, modifier = Modifier.fillMaxWidth())
                            } else {
                                r.items.forEach { item ->
                                    OutlinedButton(onClick = { spectatorChoice = item; showReveal = false }, modifier = Modifier.fillMaxWidth()) {
                                        Text(if (spectatorChoice == item) "✓  $item" else item)
                                    }
                                }
                            }
                            Button(onClick = {
                                val result = ForceEngine.resolve(r, spectatorChoice)
                                if (result.isValid) {
                                    revealText = result.revealedPrediction
                                    showReveal = true
                                } else {
                                    revealText = "الاختيار غير صالح"
                                    showReveal = true
                                }
                            }, enabled = spectatorChoice.isNotBlank(), modifier = Modifier.fillMaxWidth()) { Text("تأكيد الاختيار") }
                            if (showReveal) {
                                Card(Modifier.fillMaxWidth()) {
                                    Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                                        Text("التوقع", style = MaterialTheme.typography.titleMedium)
                                        Text(revealText, style = MaterialTheme.typography.headlineMedium, color = MaterialTheme.colorScheme.primary)
                                        if (r.imageUri.isNotBlank()) OutlinedButton(
                                            onClick = { launchUri(r.imageUri, "image/*") }, modifier = Modifier.fillMaxWidth()
                                        ) { Text("كشف صورة التوقع") }
                                        if (r.videoUri.isNotBlank()) Button(
                                            onClick = { launchUri(r.videoUri, "video/*") }, modifier = Modifier.fillMaxWidth()
                                        ) { Text("تشغيل فيديو التوقع") }
                                    }
                                }
                            }
                            OutlinedButton(onClick = { page = "performer"; showReveal = false }, modifier = Modifier.fillMaxWidth()) {
                                Text("إنهاء وضع المتفرج")
                            }
                        }
                    }
                }
                Spacer(Modifier.height(22.dp))
                Text("نسخة 1.0 • تخزين محلي • لا يوجد اتصال شبكي", style = MaterialTheme.typography.labelSmall)
            }
        }
    }
}
