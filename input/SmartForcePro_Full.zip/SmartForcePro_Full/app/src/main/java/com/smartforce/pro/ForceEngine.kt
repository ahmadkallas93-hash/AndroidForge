package com.smartforce.pro

/**
 * Core routines for a stage-magic choice demonstration.
 *
 * IMPORTANT: this is a deterministic presentation force: all spectator
 * selections are recorded, while the configured reveal is returned as the
 * prediction. It is not speech recognition and does not secretly listen
 * to the spectator. Do not describe it as a psychologically free choice.
 */
data class ForceRoutine(
    val id: String,
    val title: String,
    val category: String,
    val items: List<String>,
    val target: String,
    val videoUri: String = "",
    val imageUri: String = "",
    val performerPin: String = "2580"
)

data class ChoiceResult(
    val selectedBySpectator: String,
    val revealedPrediction: String,
    val isValid: Boolean
)

object ForceEngine {
    fun validate(routine: ForceRoutine): String? {
        if (routine.title.isBlank()) return "أدخل اسم الخدعة"
        if (routine.target.isBlank()) return "حدد النتيجة المستهدفة"
        if (routine.category != "رقم" && routine.items.isEmpty()) return "أضف عناصر للقائمة"
        if (routine.category != "رقم" && routine.target !in routine.items) {
            return "يجب أن تكون النتيجة المستهدفة ضمن القائمة"
        }
        return null
    }

    fun resolve(routine: ForceRoutine, spectatorChoice: String): ChoiceResult {
        val valid = if (routine.category == "رقم") {
            spectatorChoice.toIntOrNull() != null
        } else {
            spectatorChoice in routine.items
        }
        return ChoiceResult(
            selectedBySpectator = spectatorChoice,
            revealedPrediction = routine.target,
            isValid = valid
        )
    }
}
