package com.smartforce.pro

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.util.UUID

class RoutineStore(context: Context) {
    private val prefs = context.getSharedPreferences("smart_force_local", Context.MODE_PRIVATE)

    fun all(): List<ForceRoutine> {
        val raw = prefs.getString("routines", "[]") ?: "[]"
        return try {
            val arr = JSONArray(raw)
            (0 until arr.length()).map { i ->
                val o = arr.getJSONObject(i)
                val itemsJson = o.optJSONArray("items") ?: JSONArray()
                ForceRoutine(
                    id = o.optString("id"),
                    title = o.optString("title"),
                    category = o.optString("category", "دولة"),
                    items = (0 until itemsJson.length()).map { itemsJson.optString(it) },
                    target = o.optString("target"),
                    videoUri = o.optString("videoUri"),
                    imageUri = o.optString("imageUri"),
                    performerPin = o.optString("performerPin", "2580")
                )
            }
        } catch (_: Exception) { emptyList() }
    }

    fun save(routine: ForceRoutine) {
        val list = all().filterNot { it.id == routine.id } + routine
        val arr = JSONArray()
        list.forEach { r ->
            val o = JSONObject()
            o.put("id", r.id)
            o.put("title", r.title)
            o.put("category", r.category)
            o.put("items", JSONArray(r.items))
            o.put("target", r.target)
            o.put("videoUri", r.videoUri)
            o.put("imageUri", r.imageUri)
            o.put("performerPin", r.performerPin)
            arr.put(o)
        }
        prefs.edit().putString("routines", arr.toString()).apply()
    }

    fun delete(id: String) {
        val list = all().filterNot { it.id == id }
        val arr = JSONArray()
        list.forEach { r ->
            val o = JSONObject().apply {
                put("id", r.id); put("title", r.title); put("category", r.category)
                put("items", JSONArray(r.items)); put("target", r.target)
                put("videoUri", r.videoUri); put("imageUri", r.imageUri)
                put("performerPin", r.performerPin)
            }
            arr.put(o)
        }
        prefs.edit().putString("routines", arr.toString()).apply()
    }

    companion object {
        fun newId(): String = UUID.randomUUID().toString()
    }
}
