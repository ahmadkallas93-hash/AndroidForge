# ProGuard rules — نُبقي مكتبات Compose الأساسية بدون تشويش
-keep class androidx.compose.** { *; }
-keep class androidx.lifecycle.** { *; }
-dontwarn javax.annotation.**
